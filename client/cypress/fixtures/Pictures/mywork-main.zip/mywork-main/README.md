# mywork
posting what we done
E2E is for system testing using cypress tool 
that tests about functioanl requirments for website
it works by 
1 install node js on your device
2 install cypress using nmp install cypress command on cmd 
